package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.InvalidPatientException;

public interface IPatientService {
	String addPatientDetails(PatientBean patient) throws InvalidPatientException;
	PatientBean getPatientDeatails(String patientId) throws InvalidPatientException;
	Boolean isValidPatient(PatientBean patientBean) throws InvalidPatientException;
}
