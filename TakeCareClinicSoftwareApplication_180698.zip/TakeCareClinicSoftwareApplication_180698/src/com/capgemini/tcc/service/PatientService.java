package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.InvalidPatientException;

public class PatientService implements IPatientService {
	
	IPatientDAO idao = new PatientDAO();
	@Override
	public String addPatientDetails(PatientBean patient) throws InvalidPatientException{
		return idao.addPatientDetails(patient);
	}

	@Override
	public PatientBean getPatientDeatails(String patientId) throws InvalidPatientException{
		return idao.getPatientDeatails(patientId);
	}

	@Override
	public Boolean isValidPatient(PatientBean patientBean) throws InvalidPatientException{
		return true;
	}

}
