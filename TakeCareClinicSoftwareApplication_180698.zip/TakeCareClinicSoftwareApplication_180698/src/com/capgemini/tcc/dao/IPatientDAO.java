package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.InvalidPatientException;

public interface IPatientDAO {
	String addPatientDetails(PatientBean patient) throws  InvalidPatientException;
	PatientBean getPatientDeatails(String patientId) throws InvalidPatientException;
}
