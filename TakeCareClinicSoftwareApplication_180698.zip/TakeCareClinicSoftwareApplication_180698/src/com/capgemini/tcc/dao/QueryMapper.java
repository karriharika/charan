package com.capgemini.tcc.dao;

public interface QueryMapper {
	public static final String GET_PATIENT_DETAILS="SELECT patient_id,patient_name,age,phone,description,consultation_date FROM patient WHERE patient_id=?";
	public static final String ADD_PATIENT="INSERT INTO patient VALUES(?,?,?,?,?,SYSDATE)";
	public static final String PATIENTID_SEQUENCE_QUERY="SELECT patient_id_seq.NEXTVAL FROM DUAL";

}
